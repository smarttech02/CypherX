module.exports = {
  BOT_TOKEN: "7676914987:AAHVxRRkuXKWIllsvJHMKVsAFUpInmybFDw", // Token bot Telegram
  OWNER_ID: "6967461527", // ID pemilik bot
  allowedGroupIds: [-1002401306074, -1002361556670], // ID grup yang diizinkan
};